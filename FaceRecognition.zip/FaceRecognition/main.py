from tkinter import *
import sqlite3
from subprocess import call
import os

DATABASE = "database.db"
RECORD_FACE = "features/record_face.py"
RECOGNIZE_FACE = "features/recognition.py"


def call_record_face():
	global RECORD_FACE
	call(["python", RECORD_FACE])

def call_recognize_face():
	global RECOGNIZE_FACE_PATH
	call(["python",RECOGNIZE_FACE])



def prepare_database():
	folders = os.listdir()
	
	if(DATABASE not in folders):
		conn = sqlite3.connect(DATABASE)
		c = conn.cursor()
		
		sql = """CREATE TABLE users(
		          id integer unique primary key autoincrement,
		           name text)
		      """
		c.executescript(sql)
		conn.commit()
		conn.close()

#GUI

gui = Tk()
gui.title("Face Recognition")
gui.geometry("250x250")
gui.resizable(width=False,height=False)

record_face = Button(gui,text = "    Rekam Wajah    ",command = call_record_face)
record_face.place(x = 50,y = 40)

recognize_face = Button(gui,text = "   Recognize Wajah  ", command = call_recognize_face)
recognize_face.place(x = 50,y = 80)


prepare_database()

gui.mainloop()

